<?php
/* For license terms, see /license.txt */

use ChamiloSession as Session;

/**
 * Plugin class ava plugin.
 *
 * @package chamilo.ava
 *
 * @author Implementación de un modelo de i+d+i para gestionar y fortalecer la calidad de la educación básica y media del departamento <calidadeducativa@utch.edu.co>
 */
class AvaPlugin extends Plugin
{
    private const authors = "Proyecto Implementación de un modelo de I+D+I para gestionar y
    fortalecer la calidad de la educación básica y
    media del departamento del Chocó <br/>";

    private const settings = [
        'url_service' => 'text'
    ];

    private const version = '1.0';

    public $isAdminPlugin = true;

    /**
     * AvaPlugin constructor.
     */
    public function __construct()
    {


        parent::__construct(
            static::version,
            static::authors,
            static::settings
        );
    }

    /**
     * @return AvaPlugin
     */
    public static function create()
    {
        static $result = null;

        return $result ? $result : $result = new self();
    }

    /**
     * install plugin event.
     */
    public function install()
    {

        $this->manageTab('true');
    }

    /**
     * uninstall plugin event.
     */
    public function uninstall()
    {

        $this->manageTab('false');
    }

    /**
     * update plugin event.
     */
    public function update()
    {
    }
    // academico.
    public function academico()
    {
        $url =  empty($this->get("url_service")) ? "https://back.calidadeducativachoco.edu.co" : $this->get("url_service");
        return new Academico($url, $this->getInstitucion(), $this->getAñoElectivo(),$this->getToken());
    }

    // login de usuarios.
    public function login_ava()
    {
        $token = $this->buildToken($_REQUEST['token']);
        $institucion = $_REQUEST['institucion'];
        $año_electivo = $_REQUEST['año_electivo'];

        $academico = $this->academico();
        $academico->get_sesion($token);
        $usuario_sga = $academico->get_usuario_activo();

        if (!$usuario_sga) {
            exit('Usuario no existe');
        }

        $usuario_ava = api_get_user_info_from_username($usuario_sga['usuario']);

        if (!$usuario_ava) {
            $usuario_ava['id'] =  $this->registrar_usuario($usuario_sga);
        }

        UserManager::loginAsUser($usuario_ava['id'], false);

        Session::write('token_sga', $token);
        Session::write('institucion_sga', $institucion);
        Session::write('año_electivo_sga', $año_electivo);

        header("Location: http://localhost/chamilo-1.1.18/");
    }

    /**
     * Verifica que el token prefijo Bearer si no lo concatena a este
     * @param  string $token
     */
    private function buildToken($token)
    {
        $type_token = 'Bearer';
        return strpos($token, $type_token) !== false ? $token : "{$type_token} {$token}";
    }

    /**
     * Toma el token de la session de usuario
     * @return string
     */
    public function getToken()
    {
        return $this->buildToken(Session::read('token_sga') ?? '');
    }

    /**
     * Toma el id de la institucion de la session de usuario
     * @return integer
     */
    public function getInstitucion()
    {
        return Session::read('institucion_sga');
    }

    /**
     * Toma el id de año electivo de la session de usuario
     * @return integer
     */
    public function getAñoElectivo()
    {
        return Session::read('año_electivo_sga');
    }

    public function registrar_usuario($usuario_sga) {
        $firstName = $usuario_sga['nombre'];
        $lastName = $usuario_sga['apellido'];
        $status = 1;
        $email = $usuario_sga['correo'];
        $loginName =$usuario_sga['usuario'];
        $password =$usuario_sga['usuario'];
        $usuario_id = UserManager::create_user($firstName, $lastName, $status, $email, $loginName, $password);

        if($usuario_id == false) {
            exit('Error en crear el usuario');
        }
        return $usuario_id;
    }

    public function registrar_instituciones() {
        $academico = $this->academico();
        $academico->get_sesion($this->getToken());

        $instituciones_sga = $academico->get_instituciones();
        $cantidad_instituciones_sga = count($instituciones_sga);

        $cantidad_registros = 0;
        /*if ($entidad == 1){
            echo 'INSTITUCION';
        }
        if ($entidad == 2){
            echo 'SEDES';
        }*/
        for ($i=0; $i < $cantidad_instituciones_sga; $i++) {
            $id_institucion_sga = $instituciones_sga[$i]['InstitucionId'];
            $code_institucion_sga = "I".$id_institucion_sga;
            $name_institucion_sga = $instituciones_sga[$i]['InstitucionNombre'];
            $canHaveCourses_institucion_sga = "TRUE";
            $parent_id_institucion_sga = null;
            $id_sub_institucion_sga = "";
            //echo $code_institucion_sga;
            $code_institucion_ava = CourseCategory::getCategory($code_institucion_sga);
            //print_r($code_institucion_ava);
            if (empty($code_institucion_ava)) {
                $result[] = [
                    'code' => $code_institucion_sga,
                    'name' => $name_institucion_sga,
                    'canHaveCourses' => $canHaveCourses_institucion_sga,
                    //'parent_id' => $parent_id_institucion_sga,
                ];
               /*CourseCategory::addNode($code_institucion_sga,$name_institucion_sga,
                    $canHaveCourses_institucion_sga,$parent_id_institucion_sga);*/
                $cantidad_registros++;
            }else {
                $descripcion = 'Ya existe el registo: ' . $code_institucion_sga;
            }
        }

        /*$institucion_id = CourseCategory::guardarInstitucion($code_institucion_sga,$name_institucion_sga,
            $canHaveCourses_institucion_sga,$parent_id_institucion_sga);*/
        CourseCategory::guardarInstitucion($result,$cantidad_registros);

    }

    public function registrar_sedes() {

        $academico = $this->academico();
        $academico->get_sesion($this->getToken());

        $sedes_sga = $academico->get_sedes();
        $cantidad_sedes_sga = count($sedes_sga);

        $cantidad_registros= 0;
        for ($i=0; $i < $cantidad_sedes_sga  ; $i++) {
            $id_sede_sga = $sedes_sga[$i]['SedeId'];
            $id_institucion_sga = $sedes_sga[$i]['InstitucionId'];
            $name_sede_sga = $sedes_sga[$i]['SedeNombre'];
            $alias_sede_sga = $sedes_sga[$i]['SedeAlias'];
            $alias_institucion_sga = $sedes_sga[$i]['InstitucionAlias'];

            $code_sede_sga = "I".$id_institucion_sga."S".$id_sede_sga;
            $code_institucion_sga = "I".$id_institucion_sga;
            $canHaveCourses_sede_sga = "TRUE";
            $parent_id_sede_sga = str_replace(' ' , '', $code_institucion_sga);

            $code_sede_ava = CourseCategory::getCategory($code_sede_sga);

            if (empty($code_sede_ava)) {
                $result[] = [
                    'code' => $code_sede_sga,
                    'name' => $name_sede_sga,
                    'canHaveCourses' => $canHaveCourses_sede_sga,
                    'parent_id' => $parent_id_sede_sga,
                ];
                /*CourseCategory::addNode($code_institucion_sga,$name_institucion_sga,
                     $canHaveCourses_institucion_sga,$parent_id_institucion_sga);*/
                $cantidad_registros++;
            }else {
                $descripcion = 'Ya existe el registo: ' . $code_institucion_sga;
            }
        }

        CourseCategory::guardarInstitucion($result,$cantidad_registros);

    }

    public function registrar_docentes() {
        $academico = $this->academico();
        $docente_sga = $academico->get_docentes();

        $cantidad_docente_sga = count($docente_sga);
        $usuarioExistentes = 0;
        $usuarioRegistrado = 0;
        $usuarioError = 0;

        $result = [];
        for ($i=0; $i < $cantidad_docente_sga; $i++) {
            $docente_id_sga = $docente_sga[$i]['DocenteId'];
            $docente_identificacion_sga = $docente_sga[$i]['Identificacion'];
            $docente_primer_nombre = $docente_sga[$i]['PrimerNombre'];
            $docente_segundo_nombre = $docente_sga[$i]['SegundoNombre'];
            $docente_primer_apellido = $docente_sga[$i]['PrimerApellido'];
            $docente_segundo_pellido = $docente_sga[$i]['SegundoApellido'];
            $docente_correo_sga = $docente_sga[$i]['CorreoPrincipal'];
            $docente_telefono_sga = $docente_sga[$i]['TelefonoPrincipal'];

            $firstName = $docente_primer_nombre . " " . $docente_segundo_nombre;
            $lastName = $docente_primer_apellido . " " . $docente_segundo_pellido;
            $status = 1;
            if (empty($docente_correo_sga) || $docente_correo_sga == "-"){
                $email = 'docente@hotmail.com';
            }else{
                $email = $docente_correo_sga;
            }
            $loginName = $docente_identificacion_sga;
            $password = $docente_identificacion_sga;

            $usuario_ava = api_get_user_info_from_username($docente_identificacion_sga);

            if (!$usuario_ava) {
                $usuario_id = UserManager::create_user($firstName, $lastName, $status, $email, $loginName, $password);
                if(empty($usuario_id)) {
                    $descripcion = 'Error al registrar: ' . $loginName;
                    $usuarioError++;
                }else {
                    $descripcion = 'Registrado correctamente: '. $loginName;

//                    $table = Database::get_main_table(TABLE_P_SGA_USUARIO_DOCENTE);
//                    $params = [
//                        'id_docente_ava' =>  $usuario_id,
//                        'id_docente_sga' => $docente_id_sga,
//                    ];
//                    Database::insert($table,$params);

                    $usuarioRegistrado++;
                }
            }else{
                $descripcion = 'Ya existe el registo: ' .$docente_identificacion_sga;
                $usuarioExistentes++;
            }
//            $result[] = [
//                'descripcion' => $descripcion,
//                'tabla' => 'Docente',
//                'fecha' => date("Y-m-d H:i:s"),
//            ];
        }
        echo 'Usuarios Existentes: ' . $usuarioExistentes .'<br>';
        echo 'Usuarios Registrados: ' . $usuarioRegistrado.'<br>';
        echo 'Usuarios Error: ' . $usuarioError.'<br>';
//        $this->log_migracion($result, $usuarioExistentes, $usuarioRegistrado, $usuarioError);

    }

    public function registrar_estudiantes() {
        $academico = $this->academico();
        $estudiante_sga = $academico->get_estudiantes();

        $cantidad_estudiante_sga = count($estudiante_sga);
        $usuarioExistentes = 0;
        $usuarioRegistrado = 0;
        $usuarioError = 0;

        $result = [];
        for ($i=0; $i < $cantidad_estudiante_sga; $i++) {
            $estudiante_id_sga = $estudiante_sga[$i]['EstudianteId'];
            $estudiante_identificacion_sga = $estudiante_sga[$i]['Identificacion'];
            $estudiante_primer_nombre = $estudiante_sga[$i]['PrimerNombre'];
            $estudiante_segundo_nombre = $estudiante_sga[$i]['SegundoNombre'];
            $estudiante_primer_apellido = $estudiante_sga[$i]['PrimerApellido'];
            $estudiante_segundo_pellido = $estudiante_sga[$i]['SegundoApellido'];
            $estudiante_correo_sga = $estudiante_sga[$i]['CorreoPrincipal'];
            $estudiante_telefono_sga = $estudiante_sga[$i]['TelefonoPrincipal'];

            $firstName = $estudiante_primer_nombre . " " . $estudiante_segundo_nombre;
            $lastName = $estudiante_primer_apellido . " " . $estudiante_segundo_pellido;
            $status = 5;
            if (empty($estudiante_correo_sga) || $estudiante_correo_sga == "-"){
                $email = 'estudiante@hotmail.com';
            }else{
                $email = $estudiante_correo_sga;
            }
            $loginName = $estudiante_identificacion_sga;
            $password = $estudiante_identificacion_sga;

            $usuario_ava = api_get_user_info_from_username($estudiante_identificacion_sga);

            if (!$usuario_ava) {
                $usuario_id = UserManager::create_user($firstName, $lastName, $status, $email, $loginName, $password);
                if(empty($usuario_id)) {
                    $descripcion = 'Error al registrar: ' . $loginName;
                    $usuarioError++;
                }else {
                    $descripcion = 'Registrado correctamente: '. $loginName;

                    /*$table = Database::get_main_table(TABLE_P_SGA_USUARIO_ESTUDIANTE);
                    $params = [
                        'id_estudiante_ava' =>  $usuario_id,
                        'id_estudiante_sga' => $estudiante_id_sga,
                    ];
                    Database::insert($table,$params);*/

                    $usuarioRegistrado++;
                }
            }else{
                $descripcion = 'Ya existe el registo: ' . $estudiante_identificacion_sga;
                $usuarioExistentes++;
            }
            /*$result[] = [
                'descripcion' => $descripcion,
                'tabla' => 'Estudiante',
                'fecha' => date("Y-m-d H:i:s"),
            ];*/
        }
        echo 'Usuarios Existentes: ' . $usuarioExistentes .'<br>';
        echo 'Usuarios Registrados: ' . $usuarioRegistrado.'<br>';
        echo 'Usuarios Error: ' . $usuarioError.'<br>';
//        $this->log_migracion($result, $usuarioExistentes, $usuarioRegistrado, $usuarioError);

    }

    public function registrar_cursos() {
       /* $codes = 347;
        $idd = GroupManager::get_category($codes);
        echo $idd;
        //$id = $idd[0]['id'];
        $grupo_nombre = "Grupo";*/

       // GroupManager::create_group($grupo_nombre,2,'',0);

        $academico = $this->academico();
        $cursos_sga = $academico->get_cursos();

        $cantidad_cursos_sga = count($cursos_sga);
        $cursoExistentes = 0;
        $cursoRegistrado = 0;
        $cursoError = 0;

        $result = [];
        for ($i=0; $i < $cantidad_cursos_sga; $i++) {
            $id_curso_sga = $cursos_sga[$i]['CursoId'];
            $asignatura_id = $cursos_sga[$i]['AsignaturaId'];
            $asignatura_nombre = $cursos_sga[$i]['AsignaturaNombre'];
            $institucion_id = $cursos_sga[$i]['InstitucionId'];
            $institucion_nombre = $cursos_sga[$i]['InstitucionNombre'];
            $sede_id = $cursos_sga[$i]['SedeId'];
            $sede_nombre = $cursos_sga[$i]['SedeNombre'];
            $grado_id = $cursos_sga[$i]['GradoId'];
            $grado_nombre = $cursos_sga[$i]['GradoNombre'];
            $jornada_id = $cursos_sga[$i]['JornadaId'];
            $jornada_nombre = $cursos_sga[$i]['JornadaNombre'];
            $grupo = $cursos_sga[$i]['Grupo'];
            $docente_id = $cursos_sga[$i]['DocenteIdentificacion'];

            $instucion_curso = "I".$institucion_id."S".$sede_id;
            $title = $asignatura_nombre." - ".$grado_nombre." - ".$jornada_nombre." - "
                .$institucion_nombre." - ".$sede_nombre;
            $code = "I".$institucion_id."S".$sede_id."A".$asignatura_id."G".$grado_id."J".$jornada_id;

            $code_institucion_ava = CourseManager::getCourseIdFromCode($code);
            $user_id =UserManager::get_user_id_from_username($docente_id);
            echo "user_id: ". $user_id;
            echo "<br>";
            echo "code_institucion_ava: ". $code_institucion_ava;
            echo "<br>";
            echo "Asignatura: ". $asignatura_nombre . " - " . $grado_nombre .
                " - " . $jornada_nombre. " - " . $grupo ;
            echo "<hr>";

            if (empty($code_institucion_ava)) {

                 $curso = [
                     "title" => $title,
                     "course_category" => $instucion_curso,
                     'wanted_code' => $code,
                     "visibility" => 2,
                     "user_id" => empty($user_id) ? 1 : $user_id,
                 ];

                 $curso_idd = CourseManager::create_course($curso);

                 if(empty($curso_idd)) {
                     $descripcion = 'Error al registrar: ' . $title;
                     $cursoError++;
                 }else{
                     $descripcion ='Registrado correctamente: '. $title ;
                     //$curso_id = CourseManager::getCourseId($title);
//                    $table = Database::get_main_table(TABLE_P_SGA_CURSO);
//
//                    $params = [
//                        'id_curso_ava' =>  $curso_id,
//                        'id_curso_sga' => $id_curso_sga,
//                    ];
//                    Database::insert($table,$params);
                    $cursoRegistrado++;

                    $numero_cursoes_sga = $numero_cursoes_sga + 1;
                 }
            }else {
                if (!empty($user_id)) {
                    $TABLECOURSUSER = Database::get_main_table(TABLE_MAIN_COURSE_USER);

                    $i_course_sort = CourseManager::userCourseSort($user_id, $code);
                        Database::insert(
                            $TABLECOURSUSER,
                            [
                                'c_id' => $code_institucion_ava,
                                'user_id' => $user_id,
                                'status' => 1,
                                'is_tutor' => 0,
                                'sort' => $i_course_sort,
                                'relation_type' =>  0,
                                'user_course_cat' => 0,
                            ]
                        );
                }else{
                    echo "Vacio";
                }

                $descripcion = 'Ya existe el registo: ' .$title;
                $cursoExistentes++;
            }
            /*$code_institucion = CourseManager::getCourseIdFromCode($code);
            $idd = GroupManager::getCategoryById($curso_idd['real_id']);
            $grupo_nombre = "Grupo ".$grupo;

            GroupManager::create_group_app($code_institucion,$grupo_nombre,
                $idd,2,0);*/

        }
        echo 'Cursos Existentes: ' . $cursoExistentes .'<br>';
        echo 'Cursos Registrados: ' . $cursoRegistrado.'<br>';
        echo 'Cursos Error: ' . $cursoError.'<br>';
    }

    public function registrar_grupos(){
        $academico = $this->academico();
        $cursos_sga = $academico->get_cursos();
        $cantidad_cursos_sga = count($cursos_sga);

        $usuarioExistentes = 0;
        $usuarioRegistrado = 0;
        $usuarioError = 0;

        for ($i=0; $i < $cantidad_cursos_sga; $i++) {
            $id_curso_sga = $cursos_sga[$i]['CursoId'];
            $asignatura_id = $cursos_sga[$i]['AsignaturaId'];
            $asignatura_nombre = $cursos_sga[$i]['AsignaturaNombre'];
            $institucion_id = $cursos_sga[$i]['InstitucionId'];
            $institucion_nombre = $cursos_sga[$i]['InstitucionNombre'];
            $sede_id = $cursos_sga[$i]['SedeId'];
            $sede_nombre = $cursos_sga[$i]['SedeNombre'];
            $grado_id = $cursos_sga[$i]['GradoId'];
            $grado_nombre = $cursos_sga[$i]['GradoNombre'];
            $jornada_id = $cursos_sga[$i]['JornadaId'];
            $jornada_nombre = $cursos_sga[$i]['JornadaNombre'];
            $grupo = $cursos_sga[$i]['Grupo'];

            $code = "I".$institucion_id."S".$sede_id."A".$asignatura_id."G"
                .$grado_id."J".$jornada_id;
            $grupo_nombre = "Grupo ". $grupo;

            $code_institucion_ava = CourseManager::getCourseIdFromCode($code);
            //print_r($code_institucion_ava) ;
            if (!empty($code_institucion_ava)) {
                $id_group = GroupManager::getGroupByName($grupo_nombre,
                    $code_institucion_ava);
                //print_r($id_group['c_id']);
                if (empty($id_group)){
                    $categoria_id = GroupManager::getCategoryById($code_institucion_ava);
                    GroupManager::create_group_app ($code_institucion_ava,
                        $grupo_nombre, $categoria_id,
                    '',0);
                    $descripcion ='Registrado correctamente: '. $code ;
                    $usuarioRegistrado++;
                }
                else{
                    $descripcion = 'Ya existe el registo: ' .$code;
                    $usuarioExistentes++;
                }
            }else {
                $descripcion = 'No existe el registo: ' .$code;
                $usuarioError++;
            }

            /*$code_institucion = CourseManager::getCourseIdFromCode($code);
            $idd = GroupManager::getCategoryById($curso_idd['real_id']);
            $grupo_nombre = "Grupo ".$grupo;

            GroupManager::create_group_app($code_institucion,$grupo_nombre,
                $idd,2,0);*/

        }
        echo 'Usuarios Existentes: ' . $usuarioExistentes .'<br>';
        echo 'Usuarios Registrados: ' . $usuarioRegistrado.'<br>';
        echo 'Usuarios Error: ' . $usuarioError.'<br>';
    }

    public function registrar_tutores(){
        $academico = $this->academico();
        $cursos_sga = $academico->get_cursos();
        $cantidad_cursos_sga = count($cursos_sga);

        for ($i=0; $i < $cantidad_cursos_sga; $i++) {
            $id_curso_sga = $cursos_sga[$i]['CursoId'];
            $asignatura_id = $cursos_sga[$i]['AsignaturaId'];
            $asignatura_nombre = $cursos_sga[$i]['AsignaturaNombre'];
            $institucion_id = $cursos_sga[$i]['InstitucionId'];
            $institucion_nombre = $cursos_sga[$i]['InstitucionNombre'];
            $sede_id = $cursos_sga[$i]['SedeId'];
            $sede_nombre = $cursos_sga[$i]['SedeNombre'];
            $grado_id = $cursos_sga[$i]['GradoId'];
            $grado_nombre = $cursos_sga[$i]['GradoNombre'];
            $jornada_id = $cursos_sga[$i]['JornadaId'];
            $jornada_nombre = $cursos_sga[$i]['JornadaNombre'];
            $grupo = $cursos_sga[$i]['Grupo'];
            $docente_id = $cursos_sga[$i]['DocenteIdentificacion'];

            $code = "I" . $institucion_id . "S" . $sede_id . "A" . $asignatura_id . "G"
                . $grado_id . "J" . $jornada_id;
            $grupo_nombre = "Grupo " . $grupo;

            $usuario_ava = empty(api_get_user_info_from_username($docente_id))?'1':api_get_user_info_from_username($docente_id);
            $code_curso = CourseManager::getCourseIdFromCode($code);

            if (!empty($code_curso)) {
                $id_grupo = GroupManager::getGroupByName($grupo_nombre, $code_curso);
                if (!empty($id_grupo)){
                    GroupManager::subscribe_tutors($usuario_ava['id'], $id_grupo, $code_curso);
                    $descripcion ='Registrado correctamente: '. $code ;
                    $usuarioRegistrado++;
                }
                else{
                    $descripcion = 'No existe el registo: ' .$code;
                    $usuarioError++;
                }
            }else {
                $descripcion = 'No existe el registo: ' .$code;
                $usuarioError++;
            }
        }
    }
}
